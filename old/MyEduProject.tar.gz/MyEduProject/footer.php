
</div>
<footer class="footer" >
    <span class="">My Edu Project</span>
</footer>



</body>
</html>