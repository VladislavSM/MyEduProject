<?php
/**
 * Created by PhpStorm.
 * User: vlad
 * Date: 19.12.17
 * Time: 11:35
 */
//set_error_handler('err_handler');
//function err_handler($errno, $errmsg, $filename, $linenum) {
//    $date = date('Y-m-d H:i:s (T)');
//    $f = fopen('errors.txt', 'a');
//    if (!empty($f)) {
//        $filename  =str_replace($_SERVER['DOCUMENT_ROOT'],'',$filename);
//        $err  = "$errmsg = $filename = $linenum\r\n";
//        fwrite($f, $err);
//        fclose($f);
//    }
//}
//var_dump($_SERVER['DOCUMENT_ROOT']);die;

require_once 'SiteError.php';
$serr = new SiteError();
$serr->siteErrors();
//require_once 'SiteErroraa.php';


require_once 'header.php';
//echo $aaЫЫЫЫЫЫa;
    echo ' <div class="col-md-12">
                <br><p class="display-3">Добро пожаловать в наш магазин!</p>
           </div>';


require_once 'footer.php';



