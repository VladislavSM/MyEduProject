
<?php
require_once 'SiteError.php';
$serr = new SiteError();
$serr->siteErrors();

$stock = require_once 'stock.php';
require_once 'header.php';
?>



<div class="row item-row">

    <?php

    foreach ($stock as $item) {
        if ($item['id'] == $_GET['id']) {


            echo '<div id = "dem" class=" col-md-8 carousel slide view_item" data - ride = "carousel" >

            <!--Indicators -->
            <ul class="carousel-indicators" >
                <li data-target = "#dem" data-slide-to = "0" class="active" ></li >
                <li data-target = "#dem" data-slide-to = "1" ></li >
                <li data-target = "#dem" data-slide-to = "2" ></li >
            </ul >

            <!--The slideshow-->
            <div class="carousel-inner" >
                <div class="carousel-item active" >
                    <img class="img-fluid" src = " '.$item['imagePath'].' " alt = "Сумка MottoVoron Informa" >
                </div >
                <div class="carousel-item" >
                    <img class="img-fluid" src = "ico.png" alt = "Сумка MottoVoron Informa" >
                </div >
                <div class="carousel-item" >
                    <img class="img-fluid" src = "ico.png" alt = "Сумка MottoVoron Informa" >
                </div >
            </div >

            <!--Left and right controls-->
            <a class="carousel-control-prev" href = "#dem" data-slide = "prev" >
              <img src = "ic_skip_previous_black_48px.svg" >
            </a >
            <a class="carousel-control-next" href = "#dem" data-slide = "next" >
                <img src = "ic_skip_next_black_48px.svg" >
            </a >
        </div >


        <div class="col-md-4 item_view_details" >
            <p > '.$item['title'].' </p >
        <!--</div > -->

        <!--<div class="  item_view_details" > -->
            <p > Цена '.$item['price'].' грн.</p >
        <div class="form-for-item" >

    <form class="form-inline" action = "cart.php" method = "post" >
        <!--<div class="item_view_details" > -->

            <input type = "hidden" name = "id" value = "'.$item['id'].'" >
            <input type = "hidden" name = "title" value = " '.$item['title'].'" >
            <input type = "hidden" name = "price" value = " '.$item['price'].'" >
        <input class="amount-item-in-cart" type = "number" name = "count" min = "1" value = "1" >
        <!--</div > -->

        <!--<div class="item_view_details" > -->
            <button class="btn btn-info item_cart"  type = "submit" >
                <span class="glyphicon glyphicon-shopping-cart cart-item" ></span >
        В корзину !
            </button >
        <!--</div > -->
    </form >

        </div >

    </div >


    </div >
    <div ></div >

    <div id = "accordion" >

        <div class="card col-md-12"style = "text-align: center" >
            <div class="card-header" >
                <a class="card-link it-discr" data-toggle = "collapse" data-parent = "#accordion" href = "#collapseOne" >
            Открыть описание '.$item['title'].' .
                </a >
            </div >
            <div id = "collapseOne" class="collapse" >
                <div class="card-body" >'.$item['discription'].'
       
                </div >
            </div >
        </div >
    </div >


</div >';
        }
        else {

            $error = '<div class="col-md-12 alert alert-info page-error">
                            Выбранный Вами товар не продается в нашем магазине!
                        </div>';
        }

        };
    echo $error;
    ?>
</div>

<?php
require_once 'footer.php';