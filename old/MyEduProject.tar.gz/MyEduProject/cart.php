<?php
/**
 * Created by PhpStorm.
 * User: vlad
 * Date: 20.12.17
 * Time: 0:38
 */
if (!empty($_POST)){
    $itemToCart = $_POST;
//    var_dump($itemToCart);
};
echo 'AAAA-7777';